Sample configuration files for:
```
systemd: aetherd.service
Upstart: aetherd.conf
OpenRC:  aetherd.openrc
         aetherd.openrcconf
CentOS:  aetherd.init
macOS:   org.aether.aetherd.plist
```
have been made available to assist packagers in creating node packages here.

See [doc/init.md](../../doc/init.md) for more information.
