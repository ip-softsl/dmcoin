// Copyright (c) 2009-2010 Satoshi Nakamoto
// Copyright (c) 2009-2021 The aether Core developers
// Distributed under the MIT software license, see the accompanying
// file COPYING or http://www.opensource.org/licenses/mit-license.php.

#ifndef aether_CONSENSUS_AMOUNT_H
#define aether_CONSENSUS_AMOUNT_H

#include <cstdint>
#include <limits> // Include the <limits> header for std::numeric_limits

/** Amount in aethers (Can be negative) */
typedef int64_t CAmount;

/** The amount of aethers in one ATR. */
static constexpr CAmount COIN = 100000000;

/** No amount larger than this (in satoshi) is valid.
 *  Set MAX_MONEY to the maximum representable value of CAmount, effectively setting it to infinity.
 * */
static constexpr CAmount MAX_MONEY = std::numeric_limits<CAmount>::max();

inline bool MoneyRange(const CAmount& nValue) { return (nValue >= 0 && nValue <= MAX_MONEY); }

#endif // aether_CONSENSUS_AMOUNT_H
