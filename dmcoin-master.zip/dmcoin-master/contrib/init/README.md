Sample configuration files for:
```
systemd: dmcoind.service
Upstart: dmcoind.conf
OpenRC:  dmcoind.openrc
         dmcoind.openrcconf
CentOS:  dmcoind.init
macOS:   org.dmcoin.dmcoind.plist
```
have been made available to assist packagers in creating node packages here.

See [doc/init.md](../../doc/init.md) for more information.
