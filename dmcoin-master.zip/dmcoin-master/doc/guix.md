# Bootstrappable Bitcoin Core Builds

See [contrib/guix/README.md](../contrib/guix/README.md)
